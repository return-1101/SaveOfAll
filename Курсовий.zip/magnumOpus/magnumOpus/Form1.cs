﻿//using magnumOpus.Common.Diagnostics.SystemInfo;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.IO;
using System.Xml.Serialization;

namespace magnumOpus
{
    public partial class Form1 : Form
    {
        CpuInfo cpu = new CpuInfo(); 
        
        MotherBoard boardInfo = new MotherBoard();
        Ram ramInfo = new Ram();
        // Disk disk = new Disk();
        XmlSerializer formatter = new XmlSerializer(typeof(Settings));
        Settings setting; //= new Settings();
        string[] InfCpu;

        public Form1()
        {            
            InitializeComponent();



            using (FileStream fs = new FileStream("setting.xml", FileMode.OpenOrCreate))
            {
                try
                {

                    setting = (Settings)formatter.Deserialize(fs);
                    
                }
                catch { setting = new Settings( false); }
                Console.WriteLine("Объект десериализован");

            }
            insertInfoFromSetting();

            InfCpu = cpu.moreCpuInfo();
            //timer2.Start();

        }
             
       

        private void button2_Click(object sender, EventArgs e)
        {
            string[] infBoard = boardInfo.motherBoardInfo();
            cpu.active = false; /*timer2.Stop();*/
            label36.Text = infBoard[0];
            label35.Text = infBoard[1];
            label34.Text = infBoard[2];
            label38.Text = infBoard[3];
            label37.Text = infBoard[4];

            panel2.Visible = true;
            panel1.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
        }

        private void button3_Click(object sender, EventArgs e)
        {            
            //timer2.Stop(); timer1.Start(); cpu.active = true; 
            label17.Text = InfCpu[0];
            label18.Text = InfCpu[1];
            label19.Text = InfCpu[2];
            label20.Text = InfCpu[3];
            label21.Text = InfCpu[4];
            label22.Text = InfCpu[5];
            label23.Text = InfCpu[6];
            label24.Text = InfCpu[7];
            label25.Text = InfCpu[8];
            label26.Text = InfCpu[9];
            panel1.Visible = true;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = false;
        }
               
        private void button1_Click(object sender, EventArgs e)
        {
            cpu.active = false;
            //timer2.Start(); timer1.Stop();
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = true;
            panel4.Visible = false;

            label40.Text = ramInfo.manufaxturer;
            label39.Text = ramInfo.bank;
            label51.Text = ramInfo.capacity;
            label50.Text = ramInfo.speed;
            label55.Text = ramInfo.serialNumb;
            label54.Text = ramInfo.fizicalMemory;                        
        }

        void insertInfoFromSetting()
        {
            checkBox1.Checked = setting.setting[0].cheak;
            checkBox2.Checked = setting.setting[1].cheak;
            checkBox3.Checked = setting.setting[2].cheak;
            checkBox4.Checked = setting.setting[2].timer;
            checkBox5.Checked = setting.setting[1].timer;
            checkBox6.Checked = setting.setting[0].timer;
            checkBox7.Checked = setting.setting[5].timer;
            checkBox8.Checked = setting.setting[4].timer;
            checkBox9.Checked = setting.setting[3].timer;
            checkBox10.Checked = setting.setting[5].cheak;
            checkBox11.Checked = setting.setting[4].cheak;
            checkBox12.Checked = setting.setting[3].cheak;
            checkBox13.Checked = setting.setting[6].timer;
            checkBox14.Checked = setting.setting[6].cheak;

            checkBox20.Checked = setting.setting[7].cheak;
            checkBox19.Checked = setting.setting[8].cheak;
            checkBox18.Checked = setting.setting[9].cheak;

            checkBox17.Checked = setting.setting[7].timer;
            checkBox16.Checked = setting.setting[8].timer;
            checkBox15.Checked = setting.setting[9].timer;

            textBox11.Text = setting.setting[7].crittcalValue.ToString();
            textBox10.Text = setting.setting[8].crittcalValue.ToString();
            textBox9.Text = setting.setting[9].crittcalValue.ToString();

            textBox1.Text = setting.setting[0].crittcalValue.ToString();
            textBox2.Text = setting.setting[1].crittcalValue.ToString();
            textBox3.Text = setting.setting[2].crittcalValue.ToString();
            textBox6.Text = setting.setting[3].crittcalValue.ToString();
            textBox5.Text = setting.setting[4].crittcalValue.ToString();
            textBox4.Text = setting.setting[5].crittcalValue.ToString();
            textBox8.Text = setting.setting[6].crittcalValue.ToString();
            textBox7.Text = setting.setting[0].Time.ToString();
        }
        private void button4_Click(object sender, EventArgs e)
        {
            cpu.active = false; /*timer2.Stop(); timer1.Stop();*/
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
            panel4.Visible = true;

            insertInfoFromSetting();
        }

        //public void updateDate(object sender, EventArgs e)
        //{
        //   // cpu.GetSystemInfo();
        //    label29.Text = cpu.ClokVoltage[1] ;            
        //    label15.Text = cpu.ClokVoltage[0] + "%";
        //    label16.Text = cpu.ClokVoltage[2] + "°C";


        //}

        int convertToInt(string s)
        {
            if(s == "")
            {
                s = "0";
            }
            return int.Parse(s);
        }

        void saveSetting()
        {
            setting.setting[0].setValue("Завантаження процесора", convertToInt(textBox1.Text), convertToInt(textBox7.Text), checkBox6.Checked, checkBox1.Checked, "Процесор", checkBox1.Text);
            setting.setting[1].setValue("Температура процесора", convertToInt(textBox2.Text), convertToInt(textBox7.Text), checkBox5.Checked, checkBox2.Checked, "Процесор", checkBox2.Text);
            setting.setting[2].setValue("Частота шини процесора", convertToInt(textBox3.Text), convertToInt(textBox7.Text), checkBox4.Checked, checkBox3.Checked, "Процесор", checkBox3.Text);
            setting.setting[3].setValue("Завантаження оперативної пам'яті", convertToInt(textBox6.Text), convertToInt(textBox7.Text), checkBox9.Checked, checkBox12.Checked, "Оперативна пам'ять", checkBox12.Text);
            setting.setting[4].setValue("Зайнятий простір оперативної пам'яті", convertToInt(textBox5.Text), convertToInt(textBox7.Text), checkBox8.Checked, checkBox11.Checked, "Оперативна пам'ять", checkBox11.Text);
            setting.setting[5].setValue("Вільний простір оперативної пам'яті", convertToInt(textBox4.Text), convertToInt(textBox7.Text), checkBox7.Checked, checkBox10.Checked, "Оперативна пам'ять", checkBox10.Text);
            setting.setting[6].setValue("Завантаження диску", convertToInt(textBox8.Text), convertToInt(textBox7.Text), checkBox13.Checked, checkBox14.Checked, "Накопичувач", checkBox14.Text);

            setting.setting[7].setValue("Завантаження відеокарти", convertToInt(textBox8.Text), convertToInt(textBox7.Text), checkBox17.Checked, checkBox20.Checked, "Відеокарта", checkBox20.Text);
            setting.setting[8].setValue("Температура відеокарти", convertToInt(textBox8.Text), convertToInt(textBox7.Text), checkBox16.Checked, checkBox19.Checked, "Відеокарта", checkBox19.Text);
            setting.setting[9].setValue("Вольтаж відеокарти", convertToInt(textBox8.Text), convertToInt(textBox7.Text), checkBox15.Checked, checkBox18.Checked, "Відеокарта", checkBox18.Text);


           


            FileInfo fileInf = new FileInfo($"setting.xml");
            if (fileInf.Exists)
            {
                fileInf.Delete();
            }
           
            using (FileStream fs = new FileStream("setting.xml", FileMode.OpenOrCreate))
            {
                formatter.Serialize(fs, setting);                
            }

        }
        private void button5_Click(object sender, EventArgs e)
        {
            saveSetting();
           
            MessageBox.Show("Збереження пройшло успішно");
        }
        
        private void button6_Click(object sender, EventArgs e)
        {
            saveSetting();
            cpu.active = false;
            Form2 frm2 = new Form2(setting, button6); frm2.Show();
        }
        //private void updateRam(object sender, EventArgs e)
        //{
        //    string[] ramLoad = ramInfo.getRamInfo();

        //    label43.Text = ramLoad[0] + "%";
        //    label42.Text = ramLoad[1] + "Гб";
        //    label41.Text = ramLoad[2] + "Гб";
        //}

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label35_Click(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

       
        private void label73_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {

            char number = e.KeyChar;

            if (!Char.IsDigit(number))
            {
                e.Handled = true;
            }
           
        }
    }
}
