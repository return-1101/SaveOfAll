﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Management;
using OpenHardwareMonitor.Hardware;

namespace magnumOpus
{

           
    class CpuInfo
    {
        public string outInfo = "";
        public bool active = false;
        ManagementObjectSearcher searcher = new ManagementObjectSearcher(@"root\WMI", "SELECT * FROM MSAcpi_ThermalZoneTemperature");
        ManagementObjectSearcher cpuInformation = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Processor");
       
        
        static AutoResetEvent myEvent = new AutoResetEvent(true);

        public CpuInfo()
        {
            findValueIndex();
        }


        public string CpuVoltage()
        {
            ManagementObjectSearcher cpuInformation = new ManagementObjectSearcher("root\\CIMV2", "SELECT * FROM Win32_Processor");

            foreach (ManagementObject queryObj in cpuInformation.Get())
            {
                outInfo = (Math.Round(System.Convert.ToDouble(queryObj["CurrentVoltage"]) /*/ 10, 2*/)).ToString();
            }
            return outInfo;
        }

        public string[] moreCpuInfo()
        {
            string[] outInfo = new string[10];

            foreach (ManagementObject queryObj in cpuInformation.Get())
            {
                outInfo[0] = queryObj["Name"].ToString();
                outInfo[1] = queryObj["CurrentClockSpeed"].ToString();
                outInfo[2] = queryObj["NumberOfCores"].ToString();
                outInfo[3] = queryObj["ProcessorId"].ToString();
                outInfo[4] = queryObj["ExtClock"].ToString();
                outInfo[5] = queryObj["Family"].ToString();
                outInfo[6] = queryObj["Manufacturer"].ToString();
                outInfo[7] = queryObj["Description"].ToString();
                outInfo[8] = queryObj["L2CacheSize"].ToString() + " Кб.";
                outInfo[9] = queryObj["L3CacheSize"].ToString() + " Кб.";
            }
            return outInfo;
        }


        public string[] ClokVoltage = new string[3];

        int cpuIndex = 0, cpuTotalInd = 0, cpuBusInd = 0, cpuTempUnd = 0;
        public void findValueIndex()
        {
            Computer myComputer = new Computer();

            myComputer.CPUEnabled = true;
            myComputer.Open();
           
            myComputer.Hardware[cpuIndex].Update();
            myComputer.Hardware[cpuIndex].GetReport();



            for (int i = 0; i < myComputer.Hardware[cpuIndex].Sensors.Count(); i++) //myComputer.Hardware[15].Sensors.Count() CPU Package
            {
                if (myComputer.Hardware[cpuIndex].Sensors[i].Name == "CPU Total" || myComputer.Hardware[cpuIndex].Sensors[i].SensorType == SensorType.Load)
                {
                    cpuTotalInd = i;
                }
                else if (myComputer.Hardware[cpuIndex].Sensors[i].Name == "Bus Speed")
                {
                    cpuBusInd = i;
                }
                else if (myComputer.Hardware[cpuIndex].Sensors[i].Name == "CPU Package" || myComputer.Hardware[cpuIndex].Sensors[i].SensorType == SensorType.Load)
                {
                    cpuTempUnd = i;
                }
            }
            myComputer.Close();
        }




        public string[] GetSystemInfo()
        {         
            myEvent.WaitOne();
            Computer myComputer = new Computer();

                myComputer.Open();
                myComputer.CPUEnabled = true;
   
                myComputer.Hardware[cpuIndex].Update();
                myComputer.Hardware[cpuIndex].GetReport();

                ClokVoltage[0] = myComputer.Hardware[cpuIndex].Sensors[cpuTotalInd].Value.ToString();
                ClokVoltage[1] = myComputer.Hardware[cpuIndex].Sensors[cpuBusInd].Value.ToString();
                ClokVoltage[2] = myComputer.Hardware[cpuIndex].Sensors[cpuTempUnd].Value.ToString();

                myComputer.Close();
            myEvent.Set();
            return ClokVoltage;            
        }
    }

   


}
