﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;

namespace magnumOpus
{
    class WriteLog
    {
       // DateTime date1 = new DateTime();
        string fileName = "\\log.txt";
        string writePath;
        public WriteLog()
        {
            writePath = Environment.CurrentDirectory + fileName;

            string text = "Час запуску стеження: "+ $"{DateTime.Now }";

            using (StreamWriter sw = new StreamWriter(writePath, false, System.Text.Encoding.Default))
            {
                sw.WriteLine(text);
            }
        }
        public void writeToLog(List<CriticalAlarm> criticals)
        {
            using (StreamWriter sw = new StreamWriter(writePath, true, System.Text.Encoding.Default))
            {
                for (int i = 0; i < criticals.Count; i++)
                {
                    if (criticals[i].cheak == true)
                    {
                        sw.WriteLine($"[{DateTime.Now}]-{criticals[i].name} - {criticals[i].value}{criticals[i].typeValue}");
                    }
                }
                sw.WriteLine("------------------------------------------------------------------------");
            }
            //Thread.CurrentThread.Abort();
        }
    }
}
