﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;

namespace magnumOpus
{
    [Serializable]
    public class Settings
        {
         //public CriticalAlarm[] alarms;
            //public bool cpuLoad = true; public bool cpuLoadTimer = true;
            //public bool cpuTemperature = false; public bool cpuTemperatureTimer = false;
            //public bool cpuFrequency = false; public bool cpuFrequencyTimer = false;

            //public int informCpuLoad = 0;
            //public int informCpuTemperature = 0;
            //public int informCpuFrequency = 0;

            //public bool ramLoad = true; public bool ramLoadTimer = true;
            //public bool ramUsed = false; public bool ramUsedTimer = false;
            //public bool ramFree = false; public bool ramFreeTimer = false;

            //public int informRamLoad = 0;
            //public int informRamUsed = 0;
            //public int informRamFree = 0;

        public List <CriticalAlarm> setting = new List <CriticalAlarm>();

        public Settings() 
        {
            
        }
        public Settings(bool nePoPlanu)
        {
            setting.Add(new CriticalAlarm("Завантаження процесора", 0, 0, false, false, "Процесор", ""));
            setting.Add(new CriticalAlarm("Температура процесора", 0, 0, false, false, "Процесор", ""));
            setting.Add(new CriticalAlarm("Частота шини процесора", 0, 0, false, false, "Процесор", ""));
            setting.Add(new CriticalAlarm("Завантаження оперативної пам'яті", 0, 0, false, false, "Оперативна пам'ять", ""));
            setting.Add(new CriticalAlarm("Зайнятий простір оперативної пам'яті", 0, 0, false, false, "Оперативна пам'ять", ""));
            setting.Add(new CriticalAlarm("Вільний простір оперативної пам'яті", 0, 0, false, false, "Оперативна пам'ять", ""));
            setting.Add(new CriticalAlarm("Завантаження диску", 0, 0, false, false, "Накопичувач", ""));
            setting.Add(new CriticalAlarm("Завантаження відеокарти", 0, 0, false, false, "Відеокарта", ""));
            setting.Add(new CriticalAlarm("Температура відеокарти", 0, 0, false, false, "Відеокарта", ""));
            setting.Add(new CriticalAlarm("Вольтаж відеокарти", 0, 0, false, false, "Відеокарта", ""));
        }



    }
    
}
