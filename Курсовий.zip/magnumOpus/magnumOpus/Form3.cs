﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.IO;
using System.Windows.Forms;

namespace magnumOpus
{
    public partial class Form3 : Form
    {
        List<CriticalAlarm> infoFromLog;
        Button button;
        public Form3(List<CriticalAlarm> criticals, Button bt)
        {
            InitializeComponent();
            infoFromLog = criticals;
            button = bt;
            string fileName = "\\log.txt";
            string writePath = Environment.CurrentDirectory + fileName; ;

            insertAllFromLog(writePath);

            timer1.Start();
        }
        void insertAllFromLog(string path)
        {
            //using (StreamReader sr = new StreamReader(path))
            //{
                //richTextBox1.AppendText(sr.ReadToEnd());
            string allText = File.ReadAllText(path, Encoding.Default);
            richTextBox1.Text = allText;//sr.ReadToEnd();
           // }
        }

       
        private void timer1_Tick(object sender, EventArgs e)
        {
            for (int i = 0; i < infoFromLog.Count; i++)
            {
                if (infoFromLog[i].cheak == true)
                {
                    richTextBox1.AppendText($"[{DateTime.Now}]-{infoFromLog[i].name} - {infoFromLog[i].value}{infoFromLog[i].typeValue}\n");
                }
            }
            richTextBox1.AppendText("------------------------------------------------------------------------\n");

            if (button.Enabled == true)
            {
                Close();
            }
        }
    }
}
