﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace magnumOpus
{
   
    public class CriticalAlarm
        {
        // IFormatProvider formatter = new NumberFormatInfo { NumberDecimalSeparator = "." };
        public string type;
       public bool timer = false;
        public bool cheak = false;
            public int Time = 0;
            public string name;
            public int crittcalValue = 0;

            public double value = 0;

        public string typeValue;

        CpuInfo cpu = new CpuInfo();
        Ram ram = new Ram();
        Disk disk = new Disk();
        GpuInfo gpu = new GpuInfo();

        //Converting conv = new Converting();

        public void setValue(string n, int crit, int time, bool t, bool ch, string typ, string valT)
        {
            timer = t;
            cheak = ch;
            Time = time;
            type = typ;
            name = n;
            crittcalValue = crit;
            typeValue = valT;
        }
        public CriticalAlarm(string n, int crit, int time, bool t, bool ch, string typ, string valT)
            {
            setValue(n, crit, time, t, ch, typ, valT);
            }

            public CriticalAlarm() { }

       

        public void getValue()
        {
            switch (name)
            {
                case "Завантаження процесора":
                    value = Convert.ToDouble(cpu.GetSystemInfo()[0]);                    
                    break;
                case "Частота шини процесора":
                    value = Convert.ToDouble(cpu.GetSystemInfo()[1]);
                    break;
                case "Температура процесора":
                    value = Convert.ToDouble(cpu.GetSystemInfo()[2]);
                    break;
                case "Завантаження оперативної пам'яті":
                    value = Convert.ToDouble(ram.getRamInfo()[0]);
                    break;
                case "Зайнятий простір оперативної пам'яті":
                    value = Convert.ToDouble(ram.getRamInfo()[1]);
                    break;
                case "Вільний простір оперативної пам'яті":
                    value = Convert.ToDouble(ram.getRamInfo()[2]);
                    break;
                case "Завантаження диску":
                    value = Convert.ToDouble(disk.getDiskLoad());
                    break;
                case "Завантаження відеокарти":
                    value = Convert.ToDouble(gpu.GetGpuValue()[1]);
                    break;
                case "Температура відеокарти":
                    value = Convert.ToDouble(gpu.GetGpuValue()[2]);
                    break;
                case "Вольтаж відеокарти":
                    value = Convert.ToDouble(gpu.GetGpuValue()[0]);
                    break;
                
            }
        }

    }
    
}
