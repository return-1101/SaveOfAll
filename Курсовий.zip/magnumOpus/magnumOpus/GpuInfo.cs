﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenHardwareMonitor.Hardware;

namespace magnumOpus
{
    class GpuInfo
    {
        public GpuInfo()
        {
            findValueIndex();
        }

        public string[] ClokVoltage = new string[3];

        int gpuIndex = 0, gpuVoltage = 0, gpuLoad = 0, gpuTemperature = 0;
        public void findValueIndex()
        {
            Computer myComputer = new Computer();
            
           
            myComputer.GPUEnabled = true;
           
            myComputer.Open();

            myComputer.Hardware[gpuIndex].Update();
            myComputer.Hardware[gpuIndex].GetReport();



            for (int i = 0; i < myComputer.Hardware[gpuIndex].Sensors.Count(); i++) //myComputer.Hardware[15].Sensors.Count() CPU Package
            {
                if (myComputer.Hardware[gpuIndex].Sensors[i].SensorType == SensorType.Voltage)
                {
                    gpuVoltage = i;
                }
                else if (myComputer.Hardware[gpuIndex].Sensors[i].SensorType == SensorType.Load)
                {
                    gpuLoad = i;
                }
                else if (myComputer.Hardware[gpuIndex].Sensors[i].SensorType == SensorType.Temperature)
                {
                    gpuTemperature = i;
                }
            }
            myComputer.Close();
        }


        public string[] GetGpuValue()
        {
            
            Computer myComputer = new Computer();

            myComputer.Open();

            myComputer.GPUEnabled = true;

            myComputer.Hardware[gpuIndex].Update();
            myComputer.Hardware[gpuIndex].GetReport();

            ClokVoltage[0] = myComputer.Hardware[gpuIndex].Sensors[gpuVoltage].Value.ToString();
            ClokVoltage[1] = myComputer.Hardware[gpuIndex].Sensors[gpuLoad].Value.ToString();
            ClokVoltage[2] = myComputer.Hardware[gpuIndex].Sensors[gpuTemperature].Value.ToString();

            myComputer.Close();
            
            return ClokVoltage;
        }
    }

}

