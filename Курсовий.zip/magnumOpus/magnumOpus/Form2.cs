﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace magnumOpus
{

    public partial class Form2 : Form
    {
        public List<Label> labels = new List<Label>();
       // CriticalAlarm[] criticals;
        List<CriticalAlarm> criticals = new List<CriticalAlarm>();
        List<CriticalAlarm> whithTimer = new List<CriticalAlarm>();
        Button button;
              List<TextBox> txt = new List<TextBox>();

        Thread myThread;
        WriteLog log = new WriteLog();

        int updateTime = 1000;
        int index = 0;

        void addLabel(int top, int left, int index)
        {
            labels.Add(new Label());
            int i = labels.Count() - 1;
            labels[i].Visible = true;
            labels[i].Top = top;
            labels[i].ForeColor = Color.Black;

            criticals[index].getValue();
            if (i % 2 == 0)
            {
                labels[i].Text = $"{criticals[index].name}";
                labels[i].Size = new Size(220, 16);
            }
            else
            {
                labels[i].Text = $"{criticals[index].value}";
                labels[i].Size = new Size(80, 16);
            }

            labels[i].Left = left;

            Controls.Add(labels[i]);
        }

        void addType(int top, string text)
        {
            txt.Add(  new TextBox());
            int i = txt.Count() - 1;

            this.Controls.Add(txt[i]);
            txt[i].Top = top;
            txt[i].Text = text;
            txt[i].BorderStyle = BorderStyle.None;
            txt[i].Size = new Size(370, 16);
            txt[i].Left = 0;
            txt[i].ReadOnly = true;
                // txt[i].Enabled = false;
           
            txt[i].TextAlign = HorizontalAlignment.Center;
        }

        public Form2(Settings setting, Button bt)
        {
            InitializeComponent();
           
            bt.Enabled = false;
            
            button = bt;

            String currentType = "";

            criticals = setting.setting;

            int top = 0;

            for(int i = 0; i < criticals.Count; i++)
            {
               if (criticals[i].cheak == true)
                {
                    if (currentType != criticals[i].type)
                    {
                        top += 20;
                        currentType = criticals[i].type;
                        addType(top, currentType);
                    }                
                    top += 20;
                    addLabel(top, 30, i);
                    addLabel(top, 275, i);

                    if(criticals[i].timer == true)
                    {
                        whithTimer.Add(criticals[i]);
                    }
                }

            }

           Size = new Size(380, top+110);
            button1.Top = top+25;

            myThread = new Thread(new ThreadStart(getDate));
           myThread.Start();


            timer1.Start();
        }

        bool close = false;

       // static object locker = new object();
        void getDate()
        {  
           int alarmTime = criticals[0].Time;
            Thread logThread = new Thread(new ThreadStart(callWriteToLog));
            logThread.Start();

            while (close == false)
            {
               
                for (int i = 0; i < criticals.Count; i++)
                {
                    if (criticals[i].cheak == true)
                    {
                        criticals[i].getValue();

                        if (criticals[i].timer == true && criticals[i].value > criticals[i].crittcalValue)
                        {
                            criticals[i].Time -= 1;
                            if (criticals[i].Time <= 0)
                            {
                                MessageBox.Show($"{criticals[i].name} більше критичного значення!");
                                criticals[i].Time = alarmTime;
                            }
                        }
                        else { criticals[i].Time = alarmTime; }
                    }
                }
               
               
            }
            

        }

        void callWriteToLog()
        {
            while (close == false)
            {

                log.writeToLog(criticals);
                Thread.Sleep(updateTime);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           

           

            //labels[0].Text = labels[i].Text;

            
            
            
          

        }

        private void update(object sender, EventArgs e)
        {
            int index = 1;
            for (int i = 0; i < criticals.Count; i++)
            {
                if (criticals[i].cheak == true)
                {
                    //criticals[i].getValue();
                    if (index <= labels.Count())
                    {
                        labels[index].Text = $"{criticals[i].value}{criticals[i].typeValue}";
                        index += 2;
                    }
                }                
            }
        }

        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            close = true;
            //myThread.Abort();
            //myThread.Join();
            button.Enabled = true;            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Form3 frm3 = new Form3(criticals, button); frm3.Show();
        }
    }
}
