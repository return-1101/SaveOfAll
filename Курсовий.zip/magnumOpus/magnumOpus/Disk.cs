﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenHardwareMonitor.Hardware;
using System.Diagnostics;

namespace magnumOpus
{
    class Disk
    {
      
        public Disk()
        {           
           // getDiskInfo();
        }
        PerformanceCounter myCounter = new PerformanceCounter("PhysicalDisk", "% Disk Time", "_Total");
        
        public string getDiskLoad()
        {
            //findValueIndex();
            int load = ((int)myCounter.NextValue());
            if(load > 100)
            {
                load = 100;
            }
           return load.ToString();
        }

 
    }
}
